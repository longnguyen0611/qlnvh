package controller;
import java.sql.Connection;
import java.sql.SQLException;

public class Main {

    public static void main(String[] args) {
        new views.LoginFrame(400,200).setVisible(true);
    }
    
}
