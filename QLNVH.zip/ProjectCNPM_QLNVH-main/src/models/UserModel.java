
package models;

import java.sql.Date;

public class UserModel {
    private String Username;
    private String Password;
    private String Name;
    private String CCCD;
    private Date DateOfBirth;
    private String Location;
    private String Note;
    private boolean Block;
    private Date DateChangePass;
    private PermissionModel Permission;
    private boolean Cpass;
    
    public UserModel(String Username, String Password){
        this.Username = Username;
        this.Password = Password;
        Permission = new PermissionModel();
    }

    public void setUsername(String Username){
        this.Username = Username;
    }
    public String getUsername(){
        return this.Username;
    }
    public void setPassword(String Password){
        this.Password = Password;
    }
    public String getPassword(){
        return this.Password;
    }
    public void setName(String Name){
        this.Name = Name;
    }
    public String getName(){
        return this.Name;
    }
    public void setCCCD(String CCCD){
        this.CCCD = CCCD;
    }
    public String getCCCD(){
        return this.CCCD;
    }
    public void setDateOfBirth(Date DateOfBirth){
        this.DateOfBirth = DateOfBirth;
    }
    public Date getDateOfBirth(){
        return this.DateOfBirth;
    }
    public void setLocation(String Location){
        this.Location = Location;
    }
    public String getLocation(){
        return this.Location;
    }
    public void setPermission(PermissionModel Permission){
        this.Permission = Permission;
    }
    public PermissionModel getPermission(){
        return this.Permission;
    }
    public void setNote(String Note){
        this.Note = Note;
    }
    public String getNote(){
        return this.Note;
    }
    public void setBlock(boolean Block){
        this.Block = Block;
    }
    public boolean getBlock(){
        return this.Block;
    }
    public void setDateChangePass(Date DateChangePass){
        this.DateChangePass = DateChangePass;
    }
    public Date getDateChangePass(){
        return this.DateChangePass;
    }
    public void setCpass(boolean Cpass){
        this.Cpass = Cpass;
    }
    public boolean getCpass(){
        return this.Cpass;
    }
}
