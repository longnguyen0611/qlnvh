/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

import java.util.Vector;

public class HoKhauModel {
    private Vector dsNk;
    public HoKhauModel(){
        dsNk = new Vector();
    }
}
