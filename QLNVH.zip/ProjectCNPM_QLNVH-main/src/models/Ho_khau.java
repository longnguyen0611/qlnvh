//ten bien tieng viet ko dau cach nhau dau _
package models;

import models.Nhan_khau;
import java.util.List;


public class Ho_khau {
    private String ma_hk;
    private String ho_ten_ch;
    private int so_nguoi;
    private String ho_gd;
    private String dia_chi;
    private List<Nhan_khau> nhanKhauList;

    public Ho_khau(String ma_hk, String ho_ten_ch, int so_nguoi, String ho_gd, String dia_chi, List<Nhan_khau> nhanKhauList) {
        this.ma_hk = ma_hk;
        this.ho_ten_ch = ho_ten_ch;
        this.so_nguoi = so_nguoi;
        this.ho_gd = ho_gd;
        this.dia_chi = dia_chi;
        this.nhanKhauList = nhanKhauList;
    }

    public String getMa_hk() {
        return ma_hk;
    }

    public String getHo_ten_ch() {
        return ho_ten_ch;
    }

    public int getSo_nguoi() {
        return so_nguoi;
    }

    public String getHo_gd() {
        return ho_gd;
    }

    public String getDia_chi() {
        return dia_chi;
    }

    public List<Nhan_khau> getNhanKhauList() {
        return nhanKhauList;
    }

    public void setMa_hk(String ma_hk) {
        this.ma_hk = ma_hk;
    }

    public void setHo_ten_ch(String ho_ten_ch) {
        this.ho_ten_ch = ho_ten_ch;
    }

    public void setSo_nguoi(int so_nguoi) {
        this.so_nguoi = so_nguoi;
    }

    public void setHo_gd(String ho_gd) {
        this.ho_gd = ho_gd;
    }

    public void setDia_chi(String dia_chi) {
        this.dia_chi = dia_chi;
    }

    public void setNhanKhauList(List<Nhan_khau> nhanKhauList) {
        this.nhanKhauList = nhanKhauList;
    }

}