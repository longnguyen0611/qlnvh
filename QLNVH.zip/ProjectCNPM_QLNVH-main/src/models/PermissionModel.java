/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

import java.util.Hashtable;
/**
 *
 * @author Huân
 */
public class PermissionModel {
    private Hashtable<String, String> dscn;
    private boolean QLCSVC;
    private boolean QLPDSDNVH;
    private boolean QLNK;
    private boolean PQSDCN;
    private boolean QTND;
    private boolean QLHD;
    private boolean themhd;
    private boolean suahd;
    private boolean xoahd;
    private boolean timhd;
    private boolean xemhd;
    private boolean themcsvc;
    private boolean suacsvc;
    private boolean xoacsvc;
    private boolean timcsvc;
    private boolean xemcsvc;
    private boolean xemddk;
    private boolean chapnhanddk;
    private boolean tuchoiddk;
    private boolean themnk;
    private boolean capnhatnk;
    private boolean xoank;
    private boolean tracuunk;
    private boolean xemdscn;
    private boolean themcn;
    private boolean xoacn;
    private boolean timkiemnd;
    private boolean xemttnd;
    private boolean tdttnd;
    private boolean dkitdmk;
    private boolean yctdmkdk;
    private boolean huydktdmk;
    private boolean dkisdnvh;
    
    
    public PermissionModel(){
        QLCSVC = false;
        QLPDSDNVH = false;
        QLNK = false;
        PQSDCN = false;
        QTND = false;
        QLHD = false;
        themhd = false;
        suahd = false;
        xoahd = false;
        timhd = false;
        xemhd = false;
        themcsvc = false;
        suacsvc = false;
        xoacsvc = false;
        timcsvc = false;
        xemcsvc = false;
        xemddk = false;
        chapnhanddk = false;
        tuchoiddk = false;
        themnk = false;
        capnhatnk = false;
        xoank = false;
        tracuunk = false;
        xemdscn = false;
        xoacn = false;
        timkiemnd = false;
        xemttnd = false;
        tdttnd = false;
        dkitdmk = false;
        yctdmkdk = false;
        huydktdmk = false;
        dkisdnvh = false;
        dscn = new Hashtable<String, String>();
        dscn.put("Quản lý hoạt động", "false");
        dscn.put("Quản lý cơ sở vật chất", "false");
        dscn.put("Phân quyền sử dụng chức năng", "false");
        dscn.put("Quản lý nhân khẩu", "false");
        dscn.put("Quản lý phê duyệt sử dụng nhà văn hóa", "false");
        dscn.put("Quản trị người dùng", "false");
        dscn.put("Thêm hoạt động", "false");
        dscn.put("Sửa hoạt động", "false");
        dscn.put("Xóa hoạt động", "false");
        dscn.put("Tìm hoạt động", "false");
        dscn.put("Xem hoạt động", "false");
        dscn.put("Thêm cơ sở vật chất", "false");
        dscn.put("Sửa cơ sở vật chất", "false");
        dscn.put("Xóa cơ sở vật chất", "false");
        dscn.put("Tìm cơ sở vật chất", "false");
        dscn.put("Xem cơ sở vật chất", "false");
        dscn.put("Xem đơn đăng ký", "false");
        dscn.put("Chấp nhận đơn đăng ký", "false");
        dscn.put("Từ chối đơn đăng ký", "false");
        dscn.put("Thêm nhân khẩu", "false");
        dscn.put("Cập nhật nhân khẩu", "false");
        dscn.put("Xóa nhân khẩu", "false");
        dscn.put("Tra cứu nhân khẩu", "false");
        dscn.put("Xem danh sách chức năng", "false");
        dscn.put("Thêm chức năng", "false");
        dscn.put("Xóa chức năng", "false");
        dscn.put("Tìm kiếm người dùng", "false");
        dscn.put("Xem thông tin người dùng", "false");
        dscn.put("Thay đổi trạng thái người dùng block/unblock", "false");
        dscn.put("Thiết lập định kỳ thay đổi mật khẩu", "false");
        dscn.put("Yêu cầu người dùng thay đổi mật khẩu định kỳ", "false");
        dscn.put("Hủy định kỳ thay đổi mật khẩu", "false");
        dscn.put("Đăng ký sử dụng nhà văn hóa", "false");
    }

    public boolean getQLCSVC() {
        return QLCSVC;
    }

    public void setQLCSVC(boolean QLCSVC) {
        this.QLCSVC = QLCSVC;
        dscn.remove("Quản lý cơ sở vật chất");
        if(QLCSVC)
        dscn.put("Quản lý cơ sở vật chất", "true");
        else dscn.put("Quản lý cơ sở vật chất", "false");
    }

    public boolean getQLPDSDNVH() {
        return QLPDSDNVH;
    }

    public void setQLPDSDNVH(boolean QLPDSDNVH) {
        this.QLPDSDNVH = QLPDSDNVH;
        dscn.remove("Quản lý phê duyệt sử dụng nhà văn hóa");
        if(QLPDSDNVH)
        dscn.put("Quản lý phê duyệt sử dụng nhà văn hóa", "true");
        else dscn.put("Quản lý phê duyệt sử dụng nhà văn hóa", "false");
    }

    public boolean getQLNK() {
        return QLNK;
    }

    public void setQLNK(boolean QLNK) {
        this.QLNK = QLNK;
        dscn.remove("Quản lý nhân khẩu");
        if(QLNK)
        dscn.put("Quản lý nhân khẩu", "true");
        else dscn.put("Quản lý nhân khẩu", "false");

    }

    public boolean getPQSDCN() {
        return PQSDCN;
    }

    public void setPQSDCN(boolean PQSDCN) {
        this.PQSDCN = PQSDCN;
        dscn.remove("Phân quyền sử dụng chức năng");
        if(PQSDCN)
        dscn.put("Phân quyền sử dụng chức năng", "true");
        else dscn.put("Phân quyền sử dụng chức năng", "false");

    }

    public boolean getQTND() {
        return QTND;
    }

    public void setQTND(boolean QTND) {
        this.QTND = QTND;
        dscn.remove("Quản trị người dùng");
        if(QTND)
        dscn.put("Quản trị người dùng", "true");
        else dscn.put("Quản trị người dùng", "false");

    }

    public boolean getQLHD() {
        return QLHD;
    }

    public void setQLHD(boolean QLHD) {
        this.QLHD = QLHD;
        dscn.remove("Quản lý hoạt động");
        if(QLHD)
        dscn.put("Quản lý hoạt động", "true");
        else dscn.put("Quản lý hoạt động", "false");

    }

    public boolean getThemhd() {
        return themhd;
    }

    public void setThemhd(boolean themhd) {
        this.themhd = themhd;
        dscn.remove("Thêm hoạt động");
        if(themhd)
        dscn.put("Thêm hoạt động", "true");
        else dscn.put("Thêm hoạt động", "false");

    }

    public boolean getSuahd() {
        return suahd;
    }

    public void setSuahd(boolean suahd) {
        this.suahd = suahd;
        dscn.remove("Sửa hoạt động");
        if(suahd)
        dscn.put("Sửa hoạt động", "true");
        else dscn.put("Sửa hoạt động", "false");

    }

    public boolean getXoahd() {
        return xoahd;
    }

    public void setXoahd(boolean xoahd) {
        this.xoahd = xoahd;
        String key = "Xóa hoạt động";
        dscn.remove(key);
        if(xoahd)
        dscn.put(key, "true");
        else dscn.put(key, "false");

    }

    public boolean getTimhd() {
        return timhd;
    }

    public void setTimhd(boolean timhd) {
        this.timhd = timhd;
        String key = "Tìm hoạt động";
        dscn.remove(key);
        if(timhd)
        dscn.put(key, "true");
        else dscn.put(key, "false");

    }

    public boolean getXemhd() {
        return xemhd;
        
    }

    public void setXemhd(boolean xemhd) {
        this.xemhd = xemhd;
        String key = "Xem hoạt động";
        dscn.remove(key);
        if(xemhd)
        dscn.put(key, "true");
        else dscn.put(key, "false");

    }

    public boolean getThemcsvc() {
        return themcsvc;
    }

    public void setThemcsvc(boolean themcsvc) {
        this.themcsvc = themcsvc;
        String key = "Thêm cơ sở vật chất";
        dscn.remove(key);
        if(themcsvc)
        dscn.put(key, "true");
        else dscn.put(key, "false");
    }

    public boolean getSuacsvc() {
        return suacsvc;
    }

    public void setSuacsvc(boolean suacsvc) {
        this.suacsvc = suacsvc;
        String key = "Sửa cơ sở vật chất";
        dscn.remove(key);
        if(suacsvc)
        dscn.put(key, "true");
        else dscn.put(key, "false");
    }

    public boolean getXoacsvc() {
        return xoacsvc;
    }

    public void setXoacsvc(boolean xoacsvc) {
        this.xoacsvc = xoacsvc;
        String key = "Xóa cơ sở vật chất";
        dscn.remove(key);
        if(xoacsvc)
        dscn.put(key, "true");
        else dscn.put(key, "false");
    }

    public boolean getTimcsvc() {
        return timcsvc;
    }

    public void setTimcsvc(boolean timcsvc) {
        this.timcsvc = timcsvc;
        String key = "Tìm cơ sở vật chất";
        dscn.remove(key);
        if(timcsvc)
        dscn.put(key, "true");
        else dscn.put(key, "false");
    }

    public boolean getXemcsvc() {
        return xemcsvc;
    }

    public void setXemcsvc(boolean xemcsvc) {
        this.xemcsvc = xemcsvc;
        String key = "Xem cơ sở vật chất";
        dscn.remove(key);
        if(xemcsvc)
        dscn.put(key, "true");
        else dscn.put(key, "false");
        
    }

    public boolean getXemddk() {
        return xemddk;
    }

    public void setXemddk(boolean xemddk) {
        this.xemddk = xemddk;
        String key = "Xem đơn đăng ký";
        dscn.remove(key);
        if(xemddk)
        dscn.put(key, "true");
        else dscn.put(key, "false");
    }

    public boolean getChapnhanddk() {
        return chapnhanddk;
    }

    public void setChapnhanddk(boolean chapnhanddk) {
        this.chapnhanddk = chapnhanddk;
        String key = "Chấp nhận đơn đăng ký";
        dscn.remove(key);
        if(chapnhanddk)
        dscn.put(key, "true");
        else dscn.put(key, "false");
    }

    public boolean getTuchoiddk() {
        return tuchoiddk;
    }

    public void setTuchoiddk(boolean tuchoiddk) {
        this.tuchoiddk = tuchoiddk;
        String key = "Từ chối đơn đăng ký";
        dscn.remove(key);
        if(tuchoiddk)
        dscn.put(key, "true");
        else dscn.put(key, "false");
    }

    public boolean getThemnk() {
        return themnk;
    }

    public void setThemnk(boolean themnk) {
        this.themnk = themnk;
        String key = "Thêm nhân khẩu";
        dscn.remove(key);
        if(themnk)
        dscn.put(key, "true");
        else dscn.put(key, "false");
    }

    public boolean getCapnhatnk() {
        return capnhatnk;
    }

    public void setCapnhatnk(boolean capnhatnk) {
        this.capnhatnk = capnhatnk;
        String key = "Cập nhật nhân khẩu";
        dscn.remove(key);
        if(capnhatnk)
        dscn.put(key, "true");
        else dscn.put(key, "false");
    }

    public boolean getXoank() {
        return xoank;
    }

    public void setXoank(boolean xoank) {
        this.xoank = xoank;
        String key = "Xóa nhân khẩu";
        dscn.remove(key);
        if(xoank)
        dscn.put(key, "true");
        else dscn.put(key, "false");
    }

    public boolean getTracuunk() {
        return tracuunk;
    }

    public void setTracuunk(boolean tracuunk) {
        this.tracuunk = tracuunk;
        String key = "Tra cứu nhân khẩu";
        dscn.remove(key);
        if(tracuunk)
        dscn.put(key, "true");
        else dscn.put(key, "false");
    }

    public boolean getXemdscn() {
        return xemdscn;
    }

    public void setXemdscn(boolean xemdscn) {
        this.xemdscn = xemdscn;
        String key = "Xem danh sách chức năng";
        dscn.remove(key);
        if(xemdscn)
        dscn.put(key, "true");
        else dscn.put(key, "false");
    }

    public boolean getThemcn() {
        return themcn;
    }

    public void setThemcn(boolean themcn) {
        this.themcn = themcn;
        String key = "Thêm chức năng";
        dscn.remove(key);
        if(themcn)
        dscn.put(key, "true");
        else dscn.put(key, "false");
    }

    public boolean getXoacn() {
        return xoacn;
    }

    public void setXoacn(boolean xoacn) {
        this.xoacn = xoacn;
        String key = "Xóa chức năng";
        dscn.remove(key);
        if(xoacn)
        dscn.put(key, "true");
        else dscn.put(key, "false");
    }

    public boolean getTimkiemnd() {
        return timkiemnd;
    }

    public void setTimkiemnd(boolean timkiemnd) {
        this.timkiemnd = timkiemnd;
        String key = "Tìm kiếm người dùng";
        dscn.remove(key);
        if(timkiemnd)
        dscn.put(key, "true");
        else dscn.put(key, "false");
        
    }

    public boolean getXemttnd() {
        return xemttnd;
    }

    public void setXemttnd(boolean xemttnd) {
        this.xemttnd = xemttnd;
        String key = "Xem thông tin người dùng";
        dscn.remove(key);
        if(xemttnd)
        dscn.put(key, "true");
        else dscn.put(key, "false");
    }

    public boolean getTdttnd() {
        return tdttnd;
    }

    public void setTdttnd(boolean tdttnd) {
        this.tdttnd = tdttnd;
        String key = "Thay đổi trạng thái người dùng block/unblock";
        dscn.remove(key);
        if(tdttnd)
        dscn.put(key, "true");
        else dscn.put(key, "false");
    }

    public boolean getDkitdmk() {
        return dkitdmk;
    }

    public void setDkitdmk(boolean dkitdmk) {
        this.dkitdmk = dkitdmk;
        String key = "Thiết lập định kỳ thay đổi mật khẩu";
        dscn.remove(key);
        if(dkitdmk)
        dscn.put(key, "true");
        else dscn.put(key, "false");
    }

    public boolean getYctdmkdk() {
        return yctdmkdk;
    }

    public void setYctdmkdk(boolean yctdmkdk) {
        this.yctdmkdk = yctdmkdk;
        String key = "Yêu cầu người dùng thay đổi mật khẩu định kỳ";
        dscn.remove(key);
        if(yctdmkdk)
        dscn.put(key, "true");
        else dscn.put(key, "false");
    }

    public boolean getHuydktdmk() {
        return huydktdmk;
    }

    public void setHuydktdmk(boolean huydktdmk) {
        this.huydktdmk = huydktdmk;
        String key = "Hủy định kỳ thay đổi mật khẩu";
        dscn.remove(key);
        if(huydktdmk)
        dscn.put(key, "true");
        else dscn.put(key, "false");
    }

    public boolean getDkisdnvh() {
        return dkisdnvh;
    }

    public void setDkisdnvh(boolean dkisdnvh) {
        this.dkisdnvh = dkisdnvh;
        String key = "Đăng ký sử dụng nhà văn hóa";
        dscn.remove(key);
        if(dkisdnvh)
        dscn.put(key, "true");
        else dscn.put(key, "false");
    }
    
    public Hashtable<String,String> getDscn(){
        return this.dscn;
    }
    public void setDscn(String key, String value){
        boolean bol;
        if(value.equals("true"))bol = true;
        else bol = false;
            if(key.equals("Quản lý hoạt động"))this.setQLHD(bol);
            if(key.equals("Quản lý cơ sở vật chất"))this.setQLCSVC(bol);
            if(key.equals("Phân quyền sử dụng chức năng"))this.setPQSDCN(bol);
            if(key.equals("Quản lý nhân khẩu"))this.setQLNK(bol);
            if(key.equals("Quản lý phê duyệt sử dụng nhà văn hóa"))this.setQLPDSDNVH(bol);
            if(key.equals("Quản trị người dùng"))this.setQTND(bol);
            if(key.equals("Thêm hoạt động"))this.setThemhd(bol);
            if(key.equals("Sửa hoạt động"))this.setSuahd(bol);
            if(key.equals("Xóa hoạt động"))this.setXoahd(bol);
            if(key.equals("Tìm hoạt động"))this.setTimhd(bol);
            if(key.equals("Xem hoạt động"))this.setXemhd(bol);
            if(key.equals("Thêm cơ sở vật chất"))this.setThemcsvc(bol);
            if(key.equals("Sửa cơ sở vật chất"))this.setSuacsvc(bol);
            if(key.equals("Xóa cơ sở vật chất"))this.setXoacsvc(bol);
            if(key.equals("Tìm cơ sở vật chất"))this.setTimcsvc(bol);
            if(key.equals("Xem cơ sở vật chất"))this.setXemcsvc(bol);
            if(key.equals("Xem đơn đăng ký"))this.setXemddk(bol);
            if(key.equals("Chấp nhận đơn đăng ký"))this.setChapnhanddk(bol);
            if(key.equals("Từ chối đơn đăng ký"))this.setTuchoiddk(bol);
            if(key.equals("Thêm nhân khẩu"))this.setThemnk(bol);
            if(key.equals("Cập nhật nhân khẩu"))this.setCapnhatnk(bol);
            if(key.equals("Xóa nhân khẩu"))this.setXoank(bol);
            if(key.equals("Tra cứu nhân khẩu"))this.setTracuunk(bol);
            if(key.equals("Xem danh sách chức năng"))this.setXemdscn(bol);
            if(key.equals("Thêm chức năng"))this.setThemcn(bol);
            if(key.equals("Xóa chức năng"))this.setXoacn(bol);
            if(key.equals("Tìm kiếm người dùng"))this.setTimkiemnd(bol);
            if(key.equals("Xem thông tin người dùng"))this.setXemttnd(bol);
            if(key.equals("Thay đổi trạng thái người dùng block/unblock"))this.setTdttnd(bol);
            if(key.equals("Thiết lập định kỳ thay đổi mật khẩu"))this.setDkitdmk(bol);
            if(key.equals("Yêu cầu người dùng thay đổi mật khẩu định kỳ"))this.setYctdmkdk(bol);
            if(key.equals("Hủy định kỳ thay đổi mật khẩu"))this.setHuydktdmk(bol);
            if(key.equals("Đăng ký sử dụng nhà văn hóa"))this.setDkisdnvh(bol);

        
    }
    
}
