/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

import java.sql.Timestamp;
/**
 *
 * @author Huân
 */
public class ActivitiveModel {
    private int ID;
    private String Name;
    private Timestamp TimeFrom;
    private Timestamp TimeTo;
    private String Location;
    private String Note;
    public ActivitiveModel(String Name, Timestamp TimeFrom, Timestamp TimeTo, String Location, String Note){
        this.Name = Name;
        this.TimeFrom = TimeFrom;
        this.TimeTo = TimeTo;
        this.Location = Location;
        this.Note = Note;
    }
    public ActivitiveModel(){

    }
    public void setID(int ID){
        this.ID = ID;
    }
    public int getID(){
        return this.ID;
    }
    public void setName(String Name){
        this.Name = Name;
    }
    public String getName(){
        return this.Name;
    }
    public void setLocation(String Location){
        this.Location = Location;
    }
    public String getLocation(){
        return this.Location;
    }
    public void setNote(String Note){
        this.Note = Note;
    }
    public String getNote(){
        return this.Note;
    }
    public void setTimeFrom(Timestamp TimeFrom){
        this.TimeFrom = TimeFrom;
    }
    public Timestamp getTimeFrom(){
        return this.TimeFrom;
    }
    public void setTimeTo(Timestamp TimeTo){
        this.TimeTo = TimeTo;
    }
    public Timestamp getTimeTo(){
        return this.TimeTo;
    }

}
