/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

/**
 *
 * @author DELL
 */
public class Nhan_khau {
    private String ma_hk;
    private String ho_ten;
    private String gioi_tinh;
    private String cccd;
    private String ngay_sinh;
    private String quan_he_chu_ho;
    private String dia_chi_tt;

    public Nhan_khau(String ma_hk, String ho_ten, String gioi_tinh, String cccd, String ngay_sinh, String quan_he_chu_ho, String dia_chi_tt) {
        this.ma_hk = ma_hk;
        this.ho_ten = ho_ten;
        this.gioi_tinh = gioi_tinh;
        this.cccd = cccd;
        this.ngay_sinh = ngay_sinh;
        this.quan_he_chu_ho = quan_he_chu_ho;
        this.dia_chi_tt = dia_chi_tt;
    }

    public String getMa_hk() {
        return ma_hk;
    }

    public String getHo_ten() {
        return ho_ten;
    }

    public String getGioi_tinh() {
        return gioi_tinh;
    }

    public String getCccd() {
        return cccd;
    }

    public String getNgay_sinh() {
        return ngay_sinh;
    }

    public String getQuan_he_chu_ho() {
        return quan_he_chu_ho;
    }

    public String getDia_chi_tt() {
        return dia_chi_tt;
    }

    public void setMa_hk(String ma_hk) {
        this.ma_hk = ma_hk;
    }

    public void setHo_ten(String ho_ten) {
        this.ho_ten = ho_ten;
    }

    public void setGioi_tinh(String gioi_tinh) {
        this.gioi_tinh = gioi_tinh;
    }

    public void setCccd(String cccd) {
        this.cccd = cccd;
    }

    public void setNgay_sinh(String ngay_sinh) {
        this.ngay_sinh = ngay_sinh;
    }

    public void setQuan_he_chu_ho(String quan_he_chu_ho) {
        this.quan_he_chu_ho = quan_he_chu_ho;
    }

    public void setDia_chi_tt(String dia_chi_tt) {
        this.dia_chi_tt = dia_chi_tt;
    }
    
}
