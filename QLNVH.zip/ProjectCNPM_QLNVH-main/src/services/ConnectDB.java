/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package services;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectDB {
    private String hostName = "localhost:3306";
    private String dbName = "qlnvh";
    private String username = "root";
    private String password = "";
    
    private String connectionURL = "jdbc:mysql://"+hostName+"/"+dbName;
    
    public Connection connect(){
        Connection conn = null;
        try{
            System.out.println("ket noi thanh cong");
            conn = DriverManager.getConnection(connectionURL, username, password);
            
        }catch(SQLException e){
            System.out.println("ket noi that bai");
        }
        return conn;  
    }
            
    
}
