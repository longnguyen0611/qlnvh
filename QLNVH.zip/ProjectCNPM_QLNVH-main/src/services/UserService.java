/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package services;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.ResultSet;

/**
 *
 * @author Huân
 */
public class UserService {
    private models.UserModel User;
    private models.PermissionModel Permission;
    public UserService(models.UserModel User){
        this.User = User;
        this.Permission = User.getPermission();
    }
    public boolean UserConnection(){
        ConnectDB conn = new ConnectDB();
        Connection connect = conn.connect();
        String query = "SELECT * FROM users WHERE username = ? AND password = ?";
        PreparedStatement pstm = null;
        
        try{
            pstm = connect.prepareStatement(query);
            
            
            pstm.setString(1, User.getUsername());
            pstm.setString(2, User.getPassword());
            
            ResultSet rs = pstm.executeQuery();
            rs.next();
            User.setName(rs.getString("name"));
            User.setCCCD(rs.getString("cccd"));
            User.setDateOfBirth(rs.getDate("dateofbirth"));
            User.setLocation(rs.getString("location"));
            User.setNote(rs.getString("note"));
            User.setBlock(rs.getBoolean("block"));
            User.setDateChangePass(rs.getDate("datechangepass"));
            User.setCpass(rs.getBoolean("cpass"));
            return true;
                        
        }catch (SQLException e){
            e.printStackTrace();
            return false;
        } 
    }

    public boolean getPermission(){
        ConnectDB conn = new ConnectDB();
        Connection connect = conn.connect();
        String query = "SELECT * FROM permission WHERE username = ?";
        PreparedStatement pstm = null;
        
        try{
            pstm = connect.prepareStatement(query);
            
            
            pstm.setString(1, User.getUsername());
            
            ResultSet rs = pstm.executeQuery();
            rs.next();
            this.Permission.setQLHD(rs.getBoolean("QLHD"));
            this.Permission.setQLCSVC(rs.getBoolean("QLCSVC"));
            this.Permission.setQLNK(rs.getBoolean("QLNK"));
            this.Permission.setPQSDCN(rs.getBoolean("PQSDCN"));
            this.Permission.setQTND(rs.getBoolean("QTND"));
            this.Permission.setQLPDSDNVH(rs.getBoolean("QLPDSDNVH"));
            this.Permission.setThemhd(rs.getBoolean("themhd"));
            this.Permission.setSuahd(rs.getBoolean("suahd"));
            this.Permission.setXoahd(rs.getBoolean("xoahd"));
            this.Permission.setTimhd(rs.getBoolean("timhd"));
            this.Permission.setXemhd(rs.getBoolean("xemhd"));
            this.Permission.setThemcsvc(rs.getBoolean("themcsvc"));
            this.Permission.setSuacsvc(rs.getBoolean("suacsvc"));
            this.Permission.setXoacsvc(rs.getBoolean("xoacsvc"));
            this.Permission.setTimcsvc(rs.getBoolean("timcsvc"));
            this.Permission.setXemcsvc(rs.getBoolean("xemcsvc"));
            this.Permission.setXemddk(rs.getBoolean("xemddk"));
            this.Permission.setChapnhanddk(rs.getBoolean("chapnhanddk"));
            this.Permission.setTuchoiddk(rs.getBoolean("tuchoiddk"));
            this.Permission.setThemnk(rs.getBoolean("themnk"));
            this.Permission.setCapnhatnk(rs.getBoolean("capnhatnk"));
            this.Permission.setXoank(rs.getBoolean("xoank"));
            this.Permission.setTracuunk(rs.getBoolean("tracuunk"));
            this.Permission.setXemdscn(rs.getBoolean("xemdscn"));
            this.Permission.setThemcn(rs.getBoolean("themcn"));
            this.Permission.setXoacn(rs.getBoolean("xoacn"));
            this.Permission.setTimkiemnd(rs.getBoolean("timkiemnd"));
            this.Permission.setXemttnd(rs.getBoolean("xemttnd"));
            this.Permission.setTdttnd(rs.getBoolean("tdttnd"));
            this.Permission.setDkitdmk(rs.getBoolean("dkitdmk"));
            this.Permission.setYctdmkdk(rs.getBoolean("yctdmkdk"));
            this.Permission.setHuydktdmk(rs.getBoolean("huydktdmk"));
            this.Permission.setDkisdnvh(rs.getBoolean("dkisdnvh"));
            System.out.println("Lấy danh sách chức năng thành công" + this.Permission.getDscn().size());
            return true;
                        
        }catch (SQLException e){
            e.printStackTrace();
            return false;
        } 
    }
    private int conv(boolean bol){
        if(bol)return 1;
        return 0;
    }
    public boolean updatePermission(){
        ConnectDB conn = new ConnectDB();
        Connection connect = conn.connect();
        String query = "UPDATE permission SET "
                + "QLHD = ?, "
                + "QLCSVC = ?, "
                + "QLPDSDNVH = ?, "
                + "QLNK = ?, "
                + "PQSDCN = ?, "
                + "QTND = ?, "
                + "themhd = ?, "
                + "suahd = ?, "
                + "xoahd = ?, "
                + "timhd = ?, "
                + "xemhd = ?, "
                + "themcsvc = ?, "
                + "suacsvc = ?, "
                + "xoacsvc = ?, "
                + "timcsvc = ?, "
                + "xemcsvc = ?, "
                + "xemddk = ?, "
                + "chapnhanddk = ?, "
                + "tuchoiddk = ?, "
                + "themnk = ?, "
                + "capnhatnk = ?, "
                + "xoank = ?, "
                + "tracuunk = ?, "
                + "xemdscn = ?, "
                + "themcn = ?, "
                + "xoacn = ?, "
                + "timkiemnd = ?, "
                + "xemttnd = ?, "
                + "tdttnd = ?, "
                + "dkitdmk = ?, "
                + "yctdmkdk = ?, "
                + "huydktdmk = ?, "
                + "dkisdnvh = ? "
                + "WHERE username = ?";
        PreparedStatement pstm = null;
        
        try{
            pstm = connect.prepareStatement(query);
            pstm.setInt(1, conv(User.getPermission().getQLHD()));
            pstm.setInt(2, conv(User.getPermission().getQLCSVC()));
            pstm.setInt(3, conv(User.getPermission().getQLPDSDNVH()));
            pstm.setInt(4, conv(User.getPermission().getQLNK()));
            pstm.setInt(5, conv(User.getPermission().getPQSDCN()));
            pstm.setInt(6, conv(User.getPermission().getQTND()));
            pstm.setInt(7, conv(User.getPermission().getThemhd()));
            pstm.setInt(8, conv(User.getPermission().getSuahd()));
            pstm.setInt(9, conv(User.getPermission().getXoahd()));
            pstm.setInt(10, conv(User.getPermission().getTimhd()));
            pstm.setInt(11, conv(User.getPermission().getXemhd()));
            pstm.setInt(12, conv(User.getPermission().getThemcsvc()));
            pstm.setInt(13, conv(User.getPermission().getSuacsvc()));
            pstm.setInt(14, conv(User.getPermission().getXoacsvc()));
            pstm.setInt(15, conv(User.getPermission().getTimcsvc()));
            pstm.setInt(16, conv(User.getPermission().getXemcsvc()));
            pstm.setInt(17, conv(User.getPermission().getXemddk()));
            pstm.setInt(18, conv(User.getPermission().getChapnhanddk()));
            pstm.setInt(19, conv(User.getPermission().getTuchoiddk()));
            pstm.setInt(20, conv(User.getPermission().getThemnk()));
            pstm.setInt(21, conv(User.getPermission().getCapnhatnk()));
            pstm.setInt(22, conv(User.getPermission().getXoank()));
            pstm.setInt(23, conv(User.getPermission().getTracuunk()));
            pstm.setInt(24, conv(User.getPermission().getXemdscn()));
            pstm.setInt(25, conv(User.getPermission().getThemcn()));
            pstm.setInt(26, conv(User.getPermission().getXoacn()));
            pstm.setInt(27, conv(User.getPermission().getTimkiemnd()));
            pstm.setInt(28, conv(User.getPermission().getXemttnd()));
            pstm.setInt(29, conv(User.getPermission().getTdttnd()));
            pstm.setInt(30, conv(User.getPermission().getDkitdmk()));
            pstm.setInt(31, conv(User.getPermission().getYctdmkdk()));
            pstm.setInt(32, conv(User.getPermission().getHuydktdmk()));
            pstm.setInt(33, conv(User.getPermission().getDkisdnvh()));
            
            pstm.setString(34, User.getUsername());
            
            
            int row = pstm.executeUpdate();
            if (row != 0){
                pstm.close();
                return true;
            }
            

            return true;
                        
        }catch (SQLException e){
            e.printStackTrace();
            return false;
        } 
    }
    public boolean search(){
        ConnectDB conn = new ConnectDB();
        Connection connect = conn.connect();
        String query = "SELECT * FROM users WHERE username = ?";
        PreparedStatement pstm = null;
        
        try{
            pstm = connect.prepareStatement(query);
            
            
            pstm.setString(1, User.getUsername());
            
            ResultSet rs = pstm.executeQuery();
            rs.next();
            User.setName(rs.getString("name"));
            User.setCCCD(rs.getString("cccd"));
            User.setDateOfBirth(rs.getDate("dateofbirth"));
            User.setLocation(rs.getString("location"));
            User.setNote(rs.getString("note"));
            User.setBlock(rs.getBoolean("block"));
            User.setDateChangePass(rs.getDate("datechangepass"));
            User.setCpass(rs.getBoolean("cpass"));
            return true;
                        
        }catch (SQLException e){
            e.printStackTrace();
            return false;
        }
    }
    public boolean update(){
        ConnectDB conn = new ConnectDB();
        Connection connect = conn.connect();
        String query = "UPDATE users SET name=?, cccd=?, dateofbirth=?, location=?, note=?, block=?, datechangepass=?, cpass=? WHERE username = ?";
        PreparedStatement pstm = null;
        
        try{
            pstm = connect.prepareStatement(query);
            
            
            pstm.setString(1, User.getName());
            pstm.setString(2, User.getCCCD());
            pstm.setDate(3, User.getDateOfBirth());
            pstm.setString(4, User.getLocation());
            pstm.setString(5, User.getNote());
            
            if(User.getBlock())pstm.setInt(6, 1);
            else pstm.setInt(6, 0);
            pstm.setDate(7, User.getDateChangePass());
            if(User.getCpass())pstm.setInt(8, 1);
            else pstm.setInt(8, 0);
            pstm.setString(9, User.getUsername());
            
            int row = pstm.executeUpdate();
            if (row != 0){
                pstm.close();
                return true;
            }
                    
        }catch (SQLException e){
            e.printStackTrace();
            
        }
        return false;
    }
    
    public boolean ChangePass(String pass){
        ConnectDB conn = new ConnectDB();
        Connection connect = conn.connect();
        String query = "UPDATE users SET password=?, datechangepass=?, cpass=? WHERE username = ? and password = ? ";
        PreparedStatement pstm = null;
        
        try{
            pstm = connect.prepareStatement(query);
            
            pstm.setString(1, pass);
            long millis = System.currentTimeMillis();
            java.sql.Date date = new java.sql.Date(millis);
            pstm.setDate(2, date);
            pstm.setBoolean(3,false);
            pstm.setString(4, User.getUsername());
            pstm.setString(5, User.getPassword());
            
            
            int row = pstm.executeUpdate();
            if (row != 0){
                pstm.close();
                return true;
            }
                    
        }catch (SQLException e){
            e.printStackTrace();
            
        }
        return false;
    }
    
}
