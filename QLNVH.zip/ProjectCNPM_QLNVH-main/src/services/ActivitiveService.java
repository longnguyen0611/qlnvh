/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package services;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;

public class ActivitiveService {
    private Connection connect;
    private ResultSet Result;
    private int numResult;
    public ActivitiveService(){  
        ConnectDB conn = new ConnectDB();
        this.connect = conn.connect();
    }
        
    //thêm hoạt động
    public boolean insert(models.ActivitiveModel act){
        
        if(connect==null)return false;
        String query = "INSERT INTO activitive(name, timefrom, timeto, location, note ) VALUES (?, ?, ?, ?, ?)";
        PreparedStatement pstm = null;
        try{
            pstm = connect.prepareStatement(query);
            pstm.setString(1, act.getName());
            pstm.setTimestamp(2, act.getTimeFrom());
            pstm.setTimestamp(3, act.getTimeTo());
            pstm.setString(4, act.getLocation());
            pstm.setString(5, act.getNote());
            
            int row = pstm.executeUpdate();
            if (row != 0){
                pstm.close();
                return true;
            }
            
        }catch (SQLException e){
            e.printStackTrace();
        }
        return false;
        
    }
    
    //Cập nhật hoạt động
    public boolean update (models.ActivitiveModel act){
        if(connect == null)return false;
        String query = "UPDATE activitive SET name = ?, timefrom = ?, timeto = ?,location = ?, note = ? WHERE id = ?";
        PreparedStatement pstm = null;
        try{
            pstm = connect.prepareStatement(query);
            
            pstm.setString(1, act.getName());
            pstm.setTimestamp(2, act.getTimeFrom());
            pstm.setTimestamp(3, act.getTimeTo());
            pstm.setString(4, act.getLocation());
            pstm.setString(5, act.getNote());
            pstm.setInt(6, act.getID());
            
            int row = pstm.executeUpdate();
            if (row != 0){
                pstm.close();
                return true;
            }
            
        }catch (SQLException e){
            e.printStackTrace();
        }
        return false;
    }
    
    //Xóa hoạt động
    public boolean delete(models.ActivitiveModel act){
        if(connect==null)return false;
        String query = "DELETE FROM activitive WHERE id = ?";
        PreparedStatement pstm = null;
        try{
            pstm = connect.prepareStatement(query);
            
            pstm.setInt(1, act.getID());
            
            //Thực hiện lệnh
            int row = pstm.executeUpdate();
            if (row != 0){
                pstm.close();
                return true;
            }
            
        }catch (SQLException e){
            e.printStackTrace();
        }
        return false;
    }
    
    //Tra cứu hoạt động theo tên 
    public boolean searchActivitive(String nameActivitive){
        if(connect==null)return false;
        String query = "SELECT * FROM activitive WHERE SUBSTRING(name, 1, ?) = ? ";

        PreparedStatement pstm = null;
        
        try{
            pstm = connect.prepareStatement(query);
            
            pstm.setInt(1, nameActivitive.length());
            pstm.setString(2, nameActivitive);
            
            ResultSet rs = pstm.executeQuery();
            this.Result = rs;
            rs.last();
            this.numResult = rs.getRow();
            rs.beforeFirst();
            if(numResult == 0)return false;                        
        }catch (SQLException e){
            e.printStackTrace();
            return false;
        } 
        return true;
    }
    
    public boolean searchActivitive(int ID){
        if(connect==null)return false;
        String query = "SELECT * FROM activitive WHERE id = ? ";

        PreparedStatement pstm = null;
        
        try{
            pstm = connect.prepareStatement(query);
            
            pstm.setInt(1, ID);
            
            ResultSet rs = pstm.executeQuery();
            this.Result = rs;
            rs.last();
            this.numResult = rs.getRow();
            rs.beforeFirst();
            if(numResult == 0)return false;
                        
        }catch (SQLException e){
            e.printStackTrace();
            return false;
        } 
        return true;
    }

    
    //Thống kê hoạt động
    public boolean allActivitive(){
        if(connect==null)return false;
        String query = "SELECT * FROM activitive WHERE 1";
        
        try{
            Statement stm  = connect.createStatement();
            ResultSet rs = stm.executeQuery(query);
            this.Result = rs;
            rs.last();
            this.numResult = rs.getRow();
            rs.beforeFirst();
                        
        }catch (SQLException e){
            e.printStackTrace();
            return false;
        }
        return true;
    }
    
    //get numResult
    public int getnumResult(){
        return this.numResult;
    }
    
    //get result
    public ResultSet getResult(){
        return this.Result;
    }
    
}
