
package services;

import models.Ho_khau;
import models.Nhan_khau;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import views.JFrame_ho_khau;


public class Quan_ly_nhan_khau {
    public static List<Ho_khau> hoKhaulist=getAllHo_khau();

    public static List<Ho_khau> getHoKhaulist() {
        return hoKhaulist;
    }

    public static void setHoKhaulist(List<Ho_khau> hoKhaulist) {
        Quan_ly_nhan_khau.hoKhaulist = hoKhaulist;
    }
    // lấy ds từ csdl
    public static List<Ho_khau> getAllHo_khau(){
        List<Ho_khau> hoKhaulist=new ArrayList<>();
        //them csdl
        Statement st=null;
        ResultSet rs=null;
        try{
        String dbURL = "jdbc:mysql://localhost:3306/qlnvh";
        String username="root";
        String password="";
        Connection conn = DriverManager.getConnection(dbURL,username,password);
        if(conn!=null){
            System.out.println("Ket noi thanh cong");}
        //xem dữ liệu
        String sql="select * from hokhau";
        st = conn.createStatement();
        rs=st.executeQuery(sql);
        
        
        //xử lý dữ liệu
        
        while(rs.next()){
            //sử dụng phương thức rs.getXXString("Tên cột trong bảng")
            String mahk=rs.getString("MAHK");
            String hoten_ch=rs.getString("HOTENCH");
            int songuoi=rs.getInt("SONGUOI");
            String hogd=rs.getString("HOGD");
            String diachi=rs.getString("DIACHI");
            // Lấy danh sách nhân khẩu cho mỗi hộ khẩu
                List<Nhan_khau> nhanKhauList = getNhanKhauByMaHK(mahk);

                // Tạo đối tượng Ho_khau và thêm vào danh sách
                Ho_khau hoKhau = new Ho_khau(mahk, hoten_ch, songuoi, hogd, diachi, nhanKhauList);
                hoKhaulist.add(hoKhau);
        }
        
        }catch(SQLException e){
            System.out.println("Ket noi khong thanh cong");
        }
        return hoKhaulist;
    }
    // Lấy danh sách nhân khẩu theo mã hộ khẩu
    public static List<Nhan_khau> getNhanKhauByMaHK(String maHK) {
        List<Nhan_khau> nhanKhauList = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            String dbURL = "jdbc:mysql://localhost:3306/qlnvh";
            String username = "root";
            String password = "";
            conn = DriverManager.getConnection(dbURL, username, password);

            if (conn != null) {
                System.out.println("Ket noi thanh cong");
            }

            String sql = "SELECT * FROM nhankhau WHERE MAHK = ?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, maHK);
            rs = ps.executeQuery();

            while (rs.next()) {
                // Sử dụng các phương thức rs.getXXString("Tên cột trong bảng")
                String maHk=rs.getString("MAHK");
                String hoTen = rs.getString("HOTEN");
                String gioiTinh = rs.getString("GIOITINH");
                String cccd = rs.getString("CCCD");
                String ngaySinh = rs.getString("NGAYSINH");
                String quanHeChuHo = rs.getString("QUANHECH");
                String diaChiThuongTru = rs.getString("DIACHI_TT");

                // Tạo đối tượng Nhan_khau và thêm vào danh sách
                Nhan_khau nhanKhau = new Nhan_khau(maHk,hoTen, gioiTinh, cccd,ngaySinh, quanHeChuHo, diaChiThuongTru);
                nhanKhauList.add(nhanKhau);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return nhanKhauList;
    }
    // Xóa hộ khẩu và nhân khẩu từ cơ sở dữ liệu
    public static void deleteHo_khau(String ma_hk) {
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            String dbURL = "jdbc:mysql://localhost:3306/qlnvh";
            String username = "root";
            String password = "";
            conn = DriverManager.getConnection(dbURL, username, password);

            if (conn != null) {
                System.out.println("Ket noi thanh cong");
            }

            // Xóa nhân khẩu của hộ khẩu từ cơ sở dữ liệu
            String deleteNhanKhauSQL = "DELETE FROM nhankhau WHERE MAHK = ?";
            ps = conn.prepareStatement(deleteNhanKhauSQL);
            ps.setString(1, ma_hk);
            ps.executeUpdate();

            // Xóa hộ khẩu từ cơ sở dữ liệu
            String deleteHoKhauSQL = "DELETE FROM hokhau WHERE MAHK = ?";
            ps = conn.prepareStatement(deleteHoKhauSQL);
            ps.setString(1, ma_hk);
            ps.executeUpdate();

            // Xóa hộ khẩu từ danh sách
            List<Ho_khau> hoKhaulist = getAllHo_khau();
            Ho_khau hoKhauToRemove = null;

            for (Ho_khau hoKhau : hoKhaulist) {
                if (hoKhau.getMa_hk().equals(ma_hk)) {
                    hoKhauToRemove = hoKhau;
                    break;
                }
            }

            if (hoKhauToRemove != null) {
                hoKhaulist.remove(hoKhauToRemove);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
    //xóa nhân khẩu khi được chọn
    public static void deleteNhan_khau(String ma_hk) {
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            String dbURL = "jdbc:mysql://localhost:3306/qlnvh";
            String username = "root";
            String password = "";
            conn = DriverManager.getConnection(dbURL, username, password);

            if (conn != null) {
                System.out.println("Ket noi thanh cong");
            }

            // Xóa nhân khẩu của hộ khẩu từ cơ sở dữ liệu
            String deleteNhanKhauSQL = "DELETE FROM nhankhau WHERE MAHK = ?";
            ps = conn.prepareStatement(deleteNhanKhauSQL);
            ps.setString(1, ma_hk);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
    //xóa nhân khẩu và cập nhật số người
    public static void deleteNhan_khauAndUpdateSoNguoi(String cccd) {
    Connection conn = null;
    PreparedStatement ps = null;

    try {
        String dbURL = "jdbc:mysql://localhost:3306/qlnvh";
        String username = "root";
        String password = "";
        conn = DriverManager.getConnection(dbURL, username, password);

        if (conn != null) {
            System.out.println("Ket noi thanh cong");
        }

        // Lấy số người hiện tại trong hộ khẩu
        String mahk=JFrame_ho_khau.getPos();
        int soNguoiHienTai = getSoNguoiTrongHoKhau(mahk, conn);

        // Xóa nhân khẩu của hộ khẩu từ cơ sở dữ liệu
        String deleteNhanKhauSQL = "DELETE FROM nhankhau WHERE CCCD = ?";
        ps = conn.prepareStatement(deleteNhanKhauSQL);
        ps.setString(1, cccd);
        ps.executeUpdate();

        // Trừ đi 1 từ số người hiện tại
        int soNguoiMoi = soNguoiHienTai - 1;

        // Cập nhật số người mới vào cơ sở dữ liệu
        updateSoNguoi(mahk, soNguoiMoi, conn);

    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        try {
            if (ps != null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
    //them nhan khẩu mới
    public static void addNhan_khauAndUpdateSoNguoi(String maHk, String hoTen, String gioiTinh, String ngaySinh, String cccd, String quanHeChuHo, String diaChiTT) {
    Connection conn = null;
    PreparedStatement ps = null;

    try {
        String dbURL = "jdbc:mysql://localhost:3306/qlnvh";
        String username = "root";
        String password = "";
        conn = DriverManager.getConnection(dbURL, username, password);

        if (conn != null) {
            System.out.println("Kết nối thành công");
        }

        // Lấy số người hiện tại trong hộ khẩu
        int soNguoiHienTai = getSoNguoiTrongHoKhau(maHk, conn);

        // Thêm nhân khẩu mới vào cơ sở dữ liệu
        String addNhanKhauSQL = "INSERT INTO nhankhau (MAHK, HOTEN, GIOITINH, NGAYSINH, CCCD, QUANHECH, DIACHI_TT) VALUES (?, ?, ?, ?, ?, ?, ?)";
        ps = conn.prepareStatement(addNhanKhauSQL);
        ps.setString(1, maHk);
        ps.setString(2, hoTen);
        ps.setString(3, gioiTinh);
        ps.setString(4, ngaySinh);
        ps.setString(5, cccd);
        ps.setString(6, quanHeChuHo);
        ps.setString(7, diaChiTT);
        ps.executeUpdate();

        // Cộng thêm 1 vào số người hiện tại
        int soNguoiMoi = soNguoiHienTai + 1;

        // Cập nhật số người mới vào cơ sở dữ liệu
        updateSoNguoi(maHk, soNguoiMoi, conn);

    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        try {
            if (ps != null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}

    // Phương thức để lấy số người hiện tại trong hộ khẩu
    private static int getSoNguoiTrongHoKhau(String mahk, Connection conn) throws SQLException {
    int soNguoi = 0;
    String query = "SELECT SONGUOI FROM hokhau WHERE MAHK = ?";
    try (PreparedStatement ps = conn.prepareStatement(query)) {
        ps.setString(1, mahk);
        try (ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                soNguoi = rs.getInt("SONGUOI");
            }
        }
    }
    return soNguoi;
}

    // Phương thức để cập nhật số người mới vào cơ sở dữ liệu
    private static void updateSoNguoi(String mahk, int soNguoiMoi, Connection conn) throws SQLException {
    String updateSoNguoiSQL = "UPDATE hokhau SET SONGUOI = ? WHERE MAHK = ?";
    try (PreparedStatement ps = conn.prepareStatement(updateSoNguoiSQL)) {
        ps.setInt(1, soNguoiMoi);
        ps.setString(2, mahk);
        ps.executeUpdate();
    }
}
    //lưu thông tin nhân khẩu sau khi thay đổi
    public static void saveDataToDatabase( String hoTen, String gioiTinh, String ngaySinh, String cccd, String quanHeChuHo, String diaChiTT) {
    Connection connection = null;
    PreparedStatement preparedStatement = null;

    try {
        // Kết nối đến database (điều chỉnh URL, tên người dùng, mật khẩu phù hợp)
        connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/qlnvh", "root", "");

        // Chuẩn bị câu truy vấn SQL để cập nhật dữ liệu trong bảng
        String sql = "UPDATE nhankhau SET HOTEN=?, GIOITINH=?, NGAYSINH=?, QUANHECH=?, DIACHI_TT=? WHERE CCCD=?";
        preparedStatement = connection.prepareStatement(sql);

        // Đặt giá trị cho các tham số trong câu truy vấn
        preparedStatement.setString(1, hoTen);
        preparedStatement.setString(2, gioiTinh);
        preparedStatement.setString(3, ngaySinh);
        preparedStatement.setString(4, quanHeChuHo);
        preparedStatement.setString(5, diaChiTT);
        preparedStatement.setString(6, cccd);

        // Thực thi câu truy vấn
        preparedStatement.executeUpdate();

        System.out.println("Dữ liệu đã được cập nhật trong database.");

    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        try {
            // Đóng kết nối và tài nguyên
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (connection != null) {
                connection.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}

    
}
