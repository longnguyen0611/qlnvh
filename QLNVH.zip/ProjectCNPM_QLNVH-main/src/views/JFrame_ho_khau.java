
package views;

import services.Quan_ly_nhan_khau;
import models.Ho_khau;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;


public class JFrame_ho_khau extends javax.swing.JFrame {
    private models.UserModel User;
    //lấy ds hộ khẩu
     List<Ho_khau> hoKhaulist = Quan_ly_nhan_khau.getHoKhaulist();
    
    private static JFrame_ho_khau instance;
    public static JFrame_ho_khau getInstance() {
        if (instance == null) {
            instance = new JFrame_ho_khau();
        }
        return instance;
    }
    JFrame_sua_ho_khau suaHoKhauFrame = new JFrame_sua_ho_khau();
    public static String pos;
    //click ra jpanel1 là ko chọn hàng trong bảng nữa
    
    //chọng 1 dong mới được xem
    private void enableYourButton() {
        yourButton.setEnabled(true);
    }

    private void disableYourButton() {
        yourButton.setEnabled(false);
    }

    private void handleViewEditButton() {
        int selectedRow = yourTable.getSelectedRow();
        if (selectedRow != -1) {
            String selectedMaHK = yourTable.getValueAt(selectedRow, 1).toString();
            // Thực hiện hành động mong muốn với mã hộ khẩu đã chọn
            // Ví dụ: Mở giao diện xem/sửa hộ khẩu với mã là selectedMaHK
            suaHoKhauFrame.updatetable_nk(suaHoKhauFrame.danhsach_nk(selectedMaHK));
        }
    }
    private void initializeTableSelectionListener() {
        yourTable.getSelectionModel().addListSelectionListener(e -> {
            int selectedRow = yourTable.getSelectedRow();
            if (selectedRow != -1) {
                enableYourButton();
            } else {
                disableYourButton();
            }
        });
    }
    JButton yourButton = new JButton("Xem/Sửa Hộ khẩu");
    JTable yourTable = new JTable();
    

        // Các thành phần khác và mã tạo giao diện...
//--------------------------------------------------------------
    public static String getPos() {
        return pos;
    }
    public static void setPos(String pos) {
        JFrame_ho_khau.pos = pos;
    }
  
//tìm kiếm thông tin hộ khẩu
    private void searchHokhau(List<Ho_khau> hoKhaulist,String ma_hk,String ho_ten_ch,String sn,String dia_chi){
    List<Ho_khau> findlist= new ArrayList<>();
    for(Ho_khau hoKhau: hoKhaulist){
        if((ma_hk.isEmpty() || hoKhau.getMa_hk().contains(ma_hk))
            && (ho_ten_ch.isEmpty() || hoKhau.getHo_ten_ch().contains(ho_ten_ch))
            && (sn.isEmpty() || String.valueOf(hoKhau.getSo_nguoi()).contains(sn))
            && (dia_chi.isEmpty() || hoKhau.getDia_chi().contains(dia_chi))){
            findlist.add(hoKhau);
        }
    }
    updateTable_hk(findlist);
    }

//chỉnh độ rộng cột trong bảng
    private void setColumnWidth(JTable model,int columnIndex, int width) {
        if (columnIndex >= 0 && columnIndex < model.getColumnCount()) {
        TableColumn column = model.getColumnModel().getColumn(columnIndex);
        column.setPreferredWidth(width);
    } else {
        System.out.println("Invalid column index: " + columnIndex);
    }
    }
//hiển thị dữ liệu lên bảng danh sách
    public void updateTable_hk(List<Ho_khau> hoKhaulist){
        DefaultTableModel model=(DefaultTableModel)jTable1.getModel();
        setColumnWidth(jTable1,0,20);
        setColumnWidth(jTable1,1,50);
        setColumnWidth(jTable1,2,80);
        setColumnWidth(jTable1,3,20);
        setColumnWidth(jTable1,4,80);
        setColumnWidth(jTable1,5,200);
        model.setRowCount(0);
        
        int stt=1;
        for(Ho_khau hoKhau:hoKhaulist){
            Object[]rowData={stt++,  hoKhau.getMa_hk(), hoKhau.getHo_ten_ch(), hoKhau.getSo_nguoi(), hoKhau.getHo_gd(), hoKhau.getDia_chi()};
            model.addRow(rowData);
        }
    }
 //chọn 1 dòng để hiển thị ds ở frame sau

    //hàm chạy ct
    public JFrame_ho_khau() {
        this.User = QLNVHFrame.getUser();
        initComponents();
        initializeTableSelectionListener();
        
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel5 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jTextField4 = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jToggleButton1 = new javax.swing.JToggleButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txt_ho_ten_ch = new javax.swing.JTextField();
        txt_so_nguoi = new javax.swing.JTextField();
        txt_dia_chi = new javax.swing.JTextField();
        jButton5 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        txt_ma_ho_khau = new javax.swing.JTextField();
        jButton6 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();

        jLabel5.setText("jLabel5");

        jLabel10.setText("jLabel10");

        jTextField4.setText("jTextField4");

        jLabel6.setText("Tên nhân khẩu:");

        jTextField1.setText("jTextField1");

        jLabel8.setText("Ngày sinh:");

        jTextField3.setText("jTextField3");

        jLabel9.setText("Hộ gia đình:");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jToggleButton1.setText("Xem hộ khẩu");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Quản lý hộ khẩu");

        jPanel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel1MouseClicked(evt);
            }
        });

        jLabel1.setText("Thông tin hộ khẩu:");

        if(User.getPermission().getTracuunk())jLabel2.setVisible(true);
        else jLabel2.setVisible(false);
        jLabel2.setText("Họ tên chủ hộ:");

        if(User.getPermission().getTracuunk())jLabel3.setVisible(true);
        else jLabel3.setVisible(false);
        jLabel3.setText("Số người:");

        if(User.getPermission().getTracuunk())jLabel4.setVisible(true);
        else jLabel4.setVisible(false);
        jLabel4.setText("Địa chỉ:");

        if(User.getPermission().getTracuunk())txt_ho_ten_ch.setVisible(true);
        else txt_ho_ten_ch.setVisible(false);

        if(User.getPermission().getTracuunk())txt_so_nguoi.setVisible(true);
        else txt_so_nguoi.setVisible(false);

        if(User.getPermission().getTracuunk())txt_dia_chi.setVisible(true);
        else txt_dia_chi.setVisible(false);

        if(User.getPermission().getTracuunk())jButton5.setVisible(true);
        else jButton5.setVisible(false);
        jButton5.setText("Tìm kiếm");
        jButton5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton5MouseClicked(evt);
            }
        });

        if(User.getPermission().getTracuunk())jLabel7.setVisible(true);
        else jLabel7.setVisible(false);
        jLabel7.setText("Mã hộ khẩu:");

        if(User.getPermission().getTracuunk())txt_ma_ho_khau.setVisible(true);
        else txt_ma_ho_khau.setVisible(false);

        jButton6.setText("Làm mới danh sách");
        jButton6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton6MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel2)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txt_ho_ten_ch, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel3)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txt_so_nguoi, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel7)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txt_ma_ho_khau, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel4)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txt_dia_chi, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addComponent(jLabel1)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(223, 223, 223)
                        .addComponent(jButton5))
                    .addComponent(jButton6))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txt_ho_ten_ch, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(txt_so_nguoi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(2, 2, 2)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(txt_ma_ho_khau, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_dia_chi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addComponent(jButton6))
        );

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "STT", "Mã hộ khẩu", "Họ tên chủ hộ", "Số người", "Hộ gia đình", "Địa chỉ"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addComponent(jScrollPane1)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(582, 582, 582))
        );

        if(User.getPermission().getThemnk())jButton1.setVisible(true);
        else jButton1.setVisible(false);
        jButton1.setText("Thêm hộ khẩu");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Xem/Sửa hộ khẩu");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("Xóa hộ khẩu");
        jButton3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton3MouseClicked(evt);
            }
        });
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setText("Quay lại");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton1)
                .addGap(18, 18, 18)
                .addComponent(jButton2)
                .addGap(18, 18, 18)
                .addComponent(jButton3)
                .addGap(99, 99, 99)
                .addComponent(jButton4)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2)
                    .addComponent(jButton3)
                    .addComponent(jButton4))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        JFrame_them_ho_khau jfthk = new JFrame_them_ho_khau();
        jfthk.show();
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        handleViewEditButton();
        
        suaHoKhauFrame.setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton5MouseClicked
        // TODO add your handling code here:
        String mahk=this.txt_ma_ho_khau.getText();
        String htch=this.txt_ho_ten_ch.getText();
        String sn=this.txt_so_nguoi.getText();
        String dc=this.txt_dia_chi.getText();
        searchHokhau(hoKhaulist,mahk,htch, sn, dc);
    }//GEN-LAST:event_jButton5MouseClicked

    private void jButton6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton6MouseClicked
        // TODO add your handling code here:
    	List<Ho_khau> hoKhaulist=Quan_ly_nhan_khau.getAllHo_khau();
        updateTable_hk(hoKhaulist);
    }//GEN-LAST:event_jButton6MouseClicked

    private void jButton3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton3MouseClicked
        // TODO add your handling code here:
        int selectedRow = jTable1.getSelectedRow();
    if (selectedRow != -1) {
        String ma_hk = jTable1.getValueAt(selectedRow, 1).toString(); // Lấy mã hộ khẩu từ cột thứ 2 (cột index 1)

        // Hiển thị hộp thoại xác nhận trước khi xóa
        int option = JOptionPane.showConfirmDialog(this, "Bạn có chắc chắn muốn xóa hộ khẩu này?", "Xác nhận xóa", JOptionPane.YES_NO_OPTION);

        if (option == JOptionPane.YES_OPTION) {
            // Gọi phương thức xóa
            Quan_ly_nhan_khau.deleteHo_khau(ma_hk);
            //List<Ho_khau> hoKhau_list = Quan_ly_nhan_khau.getHoKhaulist();
            Ho_khau hoKhauToRemove = null;

        for (Ho_khau hoKhau : hoKhaulist) {
            if (hoKhau.getMa_hk().equals(ma_hk)) {
                hoKhauToRemove = hoKhau;
                break;
            }
        }

        if (hoKhauToRemove != null) {
            hoKhaulist.remove(hoKhauToRemove);
            updateTable_hk(hoKhaulist);
            JOptionPane.showMessageDialog(this, "Xóa hộ khẩu thành công.", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "Không tìm thấy hộ khẩu cần xóa trong danh sách.", "Thông báo", JOptionPane.ERROR_MESSAGE);
        }
        }
    } else {
        JOptionPane.showMessageDialog(this, "Vui lòng chọn một dòng để xóa.", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
    }
    }//GEN-LAST:event_jButton3MouseClicked

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        int selectedRow = jTable1.getSelectedRow();
    if (selectedRow != -1 && selectedRow < jTable1.getRowCount()) {
        int columnIndex = 1; // Thay đổi index cột nếu cần
        Object rowData = jTable1.getValueAt(selectedRow, columnIndex);

        if (rowData != null) {
            pos = rowData.toString();
            System.out.println("Mã hộ khẩu được chọn: " + pos);
        } else {
            System.out.println("Danh sách này trống.");
        }
        
        // Tạo đối tượng của JFrame_sua_ho_khau và gọi phương thức updatetable_nk
        //JFrame_sua_ho_khau suaHoKhauFrame = new JFrame_sua_ho_khau();
        suaHoKhauFrame.updatetable_nk(suaHoKhauFrame.danhsach_nk(pos));
        suaHoKhauFrame.updatecombo_box(pos);
    } else {
        System.out.println("Chưa chọn hộ khẩu.");
    }
    }//GEN-LAST:event_jTable1MouseClicked

    private void jPanel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel1MouseClicked

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_jButton4ActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(JFrame_ho_khau.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(JFrame_ho_khau.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(JFrame_ho_khau.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JFrame_ho_khau.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new JFrame_ho_khau().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JToggleButton jToggleButton1;
    private javax.swing.JTextField txt_dia_chi;
    private javax.swing.JTextField txt_ho_ten_ch;
    private javax.swing.JTextField txt_ma_ho_khau;
    private javax.swing.JTextField txt_so_nguoi;
    // End of variables declaration//GEN-END:variables
}
