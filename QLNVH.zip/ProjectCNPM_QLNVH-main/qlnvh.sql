-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th1 01, 2024 lúc 05:07 PM
-- Phiên bản máy phục vụ: 10.4.28-MariaDB
-- Phiên bản PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `qlnvh`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `activitive`
--

CREATE TABLE `activitive` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(50) NOT NULL,
  `location` varchar(20) NOT NULL,
  `timefrom` datetime NOT NULL,
  `timeto` datetime NOT NULL,
  `note` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `activitive`
--

INSERT INTO `activitive` (`id`, `name`, `location`, `timefrom`, `timeto`, `note`) VALUES
(4, 'a', 't3', '2022-11-13 14:30:00', '2023-11-14 15:00:00', 'aa'),
(5, 'aaaa', 'aaa', '2023-12-12 00:00:00', '2023-12-12 00:00:00', 'qsdasdsaaqwqwq');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `csvc`
--

CREATE TABLE `csvc` (
  `ID` varchar(10) NOT NULL,
  `name` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `soluong` int(10) UNSIGNED NOT NULL,
  `nguon` varchar(35) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `giatien` int(8) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Đang đổ dữ liệu cho bảng `csvc`
--

INSERT INTO `csvc` (`ID`, `name`, `soluong`, `nguon`, `giatien`) VALUES
('1', 'Loa phát thanh', 5, 'Lạc Việt Audio', 70000),
('121', '1212', 12, 'aqqq', 1234);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `dondk`
--

CREATE TABLE `dondk` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(30) NOT NULL,
  `tenhd` varchar(50) NOT NULL,
  `diadiem` varchar(50) NOT NULL,
  `tgbd` varchar(20) NOT NULL,
  `tgkt` varchar(20) NOT NULL,
  `ghichu` text NOT NULL,
  `dscsvc` text NOT NULL,
  `tt` varchar(30) NOT NULL,
  `note` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `dondk`
--

INSERT INTO `dondk` (`id`, `username`, `tenhd`, `diadiem`, `tgbd`, `tgkt`, `ghichu`, `dscsvc`, `tt`, `note`) VALUES
(1, 'huan', 'h', '1', '1', '1', '1	', '1', 'Bị từ chối', 'sai thông tin'),
(2, 'huan', 'hát', 'tầng 3', '13-11-2020 11:30', '13-11-2020 13:30', 'không có', 'loa: 1\nmic: 2\n', 'Đã duyệt', 'a'),
(3, 'huan', 'qwuqwq', 'asasasa', 'asasa', 'sasasa', 'sasasa', 'sasa', 'Bị từ chối', 'sai tt');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `hokhau`
--

CREATE TABLE `hokhau` (
  `MAHK` varchar(5) NOT NULL,
  `HOTENCH` varchar(30) NOT NULL,
  `SONGUOI` int(11) NOT NULL,
  `HOGD` varchar(30) NOT NULL,
  `DIACHI` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `hokhau`
--

INSERT INTO `hokhau` (`MAHK`, `HOTENCH`, `SONGUOI`, `HOGD`, `DIACHI`) VALUES
('HK001', 'Nguyễn Minh Quân', 3, 'Hộ bình thường', 'số 2 TQB, Hai Bà Trưng, Hà Nội'),
('HK002', 'Trần Thanh Duyên', 4, 'Hộ cận nghèo', 'số 3 TQB, Hai Bà Trưng, Hà Nội'),
('HK003', 'Nguyễn Tiến Đạt', 3, 'Hộ nghèo', 'số 4 TQB, Hai Bà Trưng, Hà Nội'),
('HK004', 'Trần Thúy Ngọc', 4, 'Hộ có hoàn cảnh khó khăn', 'số 5 TQB, Hai Bà Trưng, Hà Nội');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `muoncsvc`
--

CREATE TABLE `muoncsvc` (
  `IDcsvc` varchar(10) NOT NULL,
  `tencsvc` varchar(25) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `soluong` int(5) UNSIGNED NOT NULL,
  `nguon` varchar(25) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `giatien` int(100) UNSIGNED NOT NULL,
  `IDnguoimuon` varchar(20) NOT NULL,
  `tennguoimuon` varchar(25) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `IDchuho` varchar(20) NOT NULL,
  `gioitinh` varchar(25) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `diachi` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL,
  `ngaysinh` varchar(10) NOT NULL,
  `qhvschuho` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL,
  `doi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Đang đổ dữ liệu cho bảng `muoncsvc`
--

INSERT INTO `muoncsvc` (`IDcsvc`, `tencsvc`, `soluong`, `nguon`, `giatien`, `IDnguoimuon`, `tennguoimuon`, `IDchuho`, `gioitinh`, `diachi`, `ngaysinh`, `qhvschuho`, `doi`) VALUES
('121', '1212', 12, 'aqqq', 1234, '000912', 'Trần Thế Hưng', 'HK01', 'Nam', 'Phủ Lý, Hà Nam', '2003-12-09', 'Chủ hộ', '1212');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `nhankhau`
--

CREATE TABLE `nhankhau` (
  `MAHK` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL,
  `HOTEN` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL,
  `GIOITINH` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL,
  `CCCD` varchar(20) NOT NULL,
  `NGAYSINH` date NOT NULL,
  `QUANHECH` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL,
  `DIACHI_TT` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `nhankhau`
--

INSERT INTO `nhankhau` (`MAHK`, `HOTEN`, `GIOITINH`, `CCCD`, `NGAYSINH`, `QUANHECH`, `DIACHI_TT`) VALUES
('HK01', 'Trần Thế Hưng', 'Nam', '000912', '2003-12-09', 'Chủ hộ', 'Phủ Lý, Hà Nam'),
('HK001', 'Nguyễn Minh Quân', 'Nam', '000000000001', '1985-05-31', 'Chủ hộ', 'số 2 TQB, Hai Bà Trưng, Hà Nội'),
('HK001', 'Vũ Mỹ Linh', 'Nữ', '000000000002', '1986-07-10', 'Vợ', 'số 2 TQB, Hai Bà Trưng, Hà Nội'),
('HK001', 'Nguyễn Tiến Dũng', 'Nam', '000000000003', '2004-08-11', 'Con trai', 'số 2 TQB, Hai Bà Trưng, Hà Nội'),
('HK002', 'Trần Thanh Duyên', 'Nữ', '000000000004', '1965-05-10', 'Chủ hộ', 'số 3 TQB, Hai Bà Trưng, Hà Nội'),
('HK002', 'Trần Trung Kiên', 'Nam', '000000000005', '1965-06-11', 'Chồng', 'số 3 TQB, Hai Bà Trưng, Hà Nội'),
('HK002', 'Trần Văn Nam', 'Nam', '000000000006', '1985-07-08', 'Con trai', 'số 3 TQB, Hai Bà Trưng, Hà Nội'),
('HK002', 'Trần Thị Thủy', 'Nữ', '000000000007', '1986-06-11', 'Con gái', 'số 3 TQB, Hai Bà Trưng, Hà Nội'),
('HK003', 'Nguyễn Tiến Đạt', 'Nam', '000000000008', '1990-11-02', 'Chủ hộ', 'số 4 TQB, Hai Bà Trưng, Hà Nội'),
('HK003', 'Nguyễn Thành Nam', 'Nam', '000000000009', '2014-12-02', 'Con Trai', 'số 4 TQB, Hai Bà Trưng, Hà Nội'),
('HK003', 'Nguyễn Thị Tuyết', 'Nữ', '000000000010', '2016-08-02', 'Con gái', 'số 4 TQB, Hai Bà Trưng, Hà Nội'),
('HK004', 'Trần Thúy Ngọc', 'Nữ', '000000000011', '1999-11-02', 'Chủ hộ', 'số 5 TQB, Hai Bà Trưng, Hà Nội'),
('HK004', 'Trần Thúy My', 'Nữ', '000000000012', '2001-03-02', 'Em gái', 'số 5 TQB, Hai Bà Trưng, Hà Nội'),
('HK004', 'Trần Quang Thắng', 'Nam', '000000000013', '1969-06-09', 'Cha', 'số 5 TQB, Hai Bà Trưng, Hà Nội'),
('HK004', 'Lý Thị Linh', 'Nữ', '000000000014', '1969-09-06', 'Mẹ', 'số 5 TQB, Hai Bà Trưng, Hà Nội');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `permission`
--

CREATE TABLE `permission` (
  `username` varchar(50) NOT NULL,
  `QLHD` tinyint(1) NOT NULL,
  `QLCSVC` tinyint(1) NOT NULL,
  `QLPDSDNVH` tinyint(1) NOT NULL,
  `QLNK` tinyint(1) NOT NULL,
  `PQSDCN` tinyint(1) NOT NULL,
  `QTND` tinyint(1) NOT NULL,
  `themhd` tinyint(1) NOT NULL,
  `suahd` tinyint(1) NOT NULL,
  `xoahd` tinyint(1) NOT NULL,
  `timhd` tinyint(1) NOT NULL,
  `xemhd` tinyint(1) NOT NULL,
  `themcsvc` tinyint(1) NOT NULL,
  `suacsvc` tinyint(1) NOT NULL,
  `xoacsvc` tinyint(1) NOT NULL,
  `timcsvc` tinyint(1) NOT NULL,
  `xemcsvc` tinyint(1) NOT NULL,
  `xemddk` tinyint(1) NOT NULL,
  `chapnhanddk` tinyint(1) NOT NULL,
  `tuchoiddk` tinyint(1) NOT NULL,
  `themnk` tinyint(1) NOT NULL,
  `capnhatnk` tinyint(1) NOT NULL,
  `xoank` tinyint(1) NOT NULL,
  `tracuunk` tinyint(1) NOT NULL,
  `xemdscn` tinyint(1) NOT NULL,
  `themcn` tinyint(1) NOT NULL,
  `xoacn` tinyint(1) NOT NULL,
  `timkiemnd` tinyint(1) NOT NULL,
  `xemttnd` tinyint(1) NOT NULL,
  `tdttnd` tinyint(1) NOT NULL,
  `dkitdmk` tinyint(1) NOT NULL,
  `yctdmkdk` tinyint(1) NOT NULL,
  `huydktdmk` tinyint(1) NOT NULL,
  `dkisdnvh` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `permission`
--

INSERT INTO `permission` (`username`, `QLHD`, `QLCSVC`, `QLPDSDNVH`, `QLNK`, `PQSDCN`, `QTND`, `themhd`, `suahd`, `xoahd`, `timhd`, `xemhd`, `themcsvc`, `suacsvc`, `xoacsvc`, `timcsvc`, `xemcsvc`, `xemddk`, `chapnhanddk`, `tuchoiddk`, `themnk`, `capnhatnk`, `xoank`, `tracuunk`, `xemdscn`, `themcn`, `xoacn`, `timkiemnd`, `xemttnd`, `tdttnd`, `dkitdmk`, `yctdmkdk`, `huydktdmk`, `dkisdnvh`) VALUES
('huan', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1),
('test', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `setting`
--

CREATE TABLE `setting` (
  `bool` tinyint(1) DEFAULT NULL,
  `numday` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `setting`
--

INSERT INTO `setting` (`bool`, `numday`) VALUES
(0, 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tracsvc`
--

CREATE TABLE `tracsvc` (
  `IDcsvc` varchar(10) NOT NULL,
  `tencsvc` varchar(25) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `soluong` int(10) UNSIGNED NOT NULL,
  `nguon` varchar(25) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `giatien` int(100) UNSIGNED NOT NULL,
  `IDnguoitra` varchar(20) NOT NULL,
  `tennguoitra` varchar(25) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `IDchuho` varchar(20) NOT NULL,
  `gioitinh` varchar(25) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `diachi` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL,
  `ngaysinh` date NOT NULL,
  `qhvschuho` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL,
  `dor` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `users`
--

CREATE TABLE `users` (
  `username` varchar(50) NOT NULL,
  `password` varchar(30) NOT NULL,
  `name` varchar(50) NOT NULL,
  `cccd` varchar(20) NOT NULL,
  `dateofbirth` date NOT NULL,
  `location` varchar(100) NOT NULL,
  `note` varchar(200) NOT NULL,
  `block` tinyint(4) NOT NULL,
  `datechangepass` date DEFAULT NULL,
  `cpass` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `users`
--

INSERT INTO `users` (`username`, `password`, `name`, `cccd`, `dateofbirth`, `location`, `note`, `block`, `datechangepass`, `cpass`) VALUES
('huan', '12', 'Trần Quang Huân', '024203000795', '2003-12-14', 'Bắc Giang', 'không', 0, '2024-01-01', 0),
('test', '1', 'Teemo', '000000', '2000-10-10', 'LMHT', 'không', 0, '2023-12-23', 0);

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `activitive`
--
ALTER TABLE `activitive`
  ADD PRIMARY KEY (`id`),
  ADD KEY `index` (`id`);

--
-- Chỉ mục cho bảng `csvc`
--
ALTER TABLE `csvc`
  ADD PRIMARY KEY (`ID`);

--
-- Chỉ mục cho bảng `dondk`
--
ALTER TABLE `dondk`
  ADD KEY `id` (`id`);

--
-- Chỉ mục cho bảng `permission`
--
ALTER TABLE `permission`
  ADD PRIMARY KEY (`username`);

--
-- Chỉ mục cho bảng `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `activitive`
--
ALTER TABLE `activitive`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT cho bảng `dondk`
--
ALTER TABLE `dondk`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
